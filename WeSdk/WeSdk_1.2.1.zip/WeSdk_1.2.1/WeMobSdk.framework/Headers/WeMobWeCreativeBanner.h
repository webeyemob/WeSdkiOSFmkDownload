//
//  WeMobCreativeBanner.h
//  WeMobMediation_Creative
//

#import "WeMobCustomBanner.h"


@interface WeMobWeCreativeBanner : WeMobCustomBanner

@end
