//
//  WeWeCreativeInterstitil.h
//  Mediation_WeDsp
//

#import "WeMobCustomInterstitial.h"


@interface WeMobWeCreativeInterstitial : WeMobCustomInterstitial

@end
