//
//  WeWeDspInterstitil.h
//  Mediation_WeDsp
//

#import "WeMobCustomInterstitial.h"


@interface WeMobWeDspInterstitial : WeMobCustomInterstitial

@end
