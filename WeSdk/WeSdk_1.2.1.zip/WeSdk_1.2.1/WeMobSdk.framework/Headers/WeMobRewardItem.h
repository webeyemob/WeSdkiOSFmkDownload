//
//  WeMobRewardItem.h

//

#import <Foundation/Foundation.h>

@interface WeMobRewardItem : NSObject

@property NSString *rewardType;
@property int rewardAmount;

@end
